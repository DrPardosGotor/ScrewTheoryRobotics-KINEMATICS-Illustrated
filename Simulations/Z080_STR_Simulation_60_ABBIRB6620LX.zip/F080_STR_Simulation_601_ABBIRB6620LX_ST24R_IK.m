%% "F080_STR_Simulation_601_ABBIRB6620LX_ST24R_IK" IRB6620LX ToolDown POSE.
%
% It solves the INVERSE KINEMATICS for any desired position & orientation
% of the TCP (noap goal) of the ABB IRB6620LX120 Robot.
% by Dr. Pardos-Gotor ST24R "Screw Theory Toolbox for Robotics" MATLAB.
% Approach by PardosGotor1+Pardosgotor4+PadenKahan2+PadenKahan1
%
% function ThetaOut = F080_STR_Simulation_601_ABBIRB6620LX_ST24R_IK(u)
%
% The inputs "u" (7x1) are composed by the following vectors.
% "traXYZ" (3x1) desired translations for the TcP (noap - "p" goal).
% "rotXYZ" (3x1) desired rotations for TcP (noap - "noa" goal order (X+Y+Z)
% "Solutions" (1x1) is the value "Theta index" for choosing one out of 8
% possible results (Solutions = 1 to 8) for Robot Joint values
% Solutions = 9 is for sending the robot to the HOME POSITION (ThetaOut=0)
% Solutions = 12 is for sending the robot to the FREEZE POSITION.
% "ThetaOut" (t1..t6)are the magnitudes solution for the Robot Joints1..6.
%
% Mechanical characteristics of the Robot (AT REF POSITION):
% po = Origen for he STATIONARY system of reference.
% pu = point in the axis of Th1(tra).
% pk = point in the axis of Th2(rot).
% pr = point in the axis of Th3(rot).
% pf = point in the crossing of the DOF Th4(rot), Th5(rot), Th6(rot).
% pp = TcP Tool Center Point
% hst0 = Tool (TcP) rot+tra at robot reference (home configuration).
%
% Next code gets the Twist & Hst0 for the robot:
%po=[0;0;0]; pu=[1088;2500;0]; % In fact pu has not use because Theta1=TRA
%pk=[1468;2500;0]; pr=[2443;2500;0];
%pf=[2643;1613;0]; pp=[3000;1613;0]; 
%AxisX = [1 0 0]'; AxisY = [0 1 0]'; AxisZ = [0 0 1]'; 
%Point = [pu pk pr pf pf pp];
%Joint = ['tra'; 'rot'; 'rot'; 'rot'; 'rot'; 'rot'];
%Axis = [AxisZ AxisZ AxisZ -AxisY AxisZ AxisX];
%Twist = zeros(6,6);
%for i = 1:6
%    Twist(:,i) = Joint2Twist(Axis(:,i), Point(:,i), Joint(i,:));
%end
%Hst0 = trvX2tform(pp(1))*trvY2tform(pp(2))*trvZ2tform(pp(3));
%Hst0 = Hst0*rotY2tform(pi/2);
%
% Copyright (C) 2003-2018, by Dr. Jose M. Pardos-Gotor.
%
% This file is part of The ST24R "Screw Theory Toolbox for Robotics" MATLAB
% 
% ST24R is free software: you can redistribute it and/or modify
% it under the terms of the GNU Lesser General Public License as published
% by the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% ST24R is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU Lesser General Public License for more details.
% 
% You should have received a copy of the GNU Leser General Public License
% along with ST24R. If not, see <http://www.gnu.org/licenses/>.
%
% http://www.
%
% CHANGES:
% Revision 1.1  2018/02/11 00:00:01
% General cleanup of code: help comments, see also, copyright
% references, clarification of functions.
%
%% F080_STR_Simulation_601_ABBIRB6620LX_ST24R_IK
%
function ThetaOut = F080_STR_Simulation_601_ABBIRB6620LX_ST24R_IK(u) %#codegen
%
persistent Theta ThetaNUM RobotMOV;
if isempty(Theta)
   Theta = zeros(10,6);
end
if isempty(ThetaNUM)
   ThetaNUM = 1;
end
if isempty(RobotMOV)
   RobotMOV = 1;
end
%
% Now we read the DashBoard for checking the solution choosen
% If "Solutions" = u(7) = 1..4 then choosing Theta1..Theta4 Solutions
% If "Solutions" = u(7) = 9 then robot to HOME position and Theta(9) = 0
% If "Solutions" = u(7) = 12 then robot FREEZE to last position Theta(10).
if u(7)<=9
    ThetaNUM = u(7);
    RobotMOV = 1;
end
%
if u(7)==12
    Theta(10,:) = Theta(ThetaNUM,:);
    ThetaNUM = 10;
    RobotMOV = 0;
end
%
% Mechanical characteristics of the Robot:
po=[0;0;0]; pf=[2.643;1.613;0]; pp=[3.000;1.613;0];
Twist = [  0       2.500       2.500           0       1.613           0;
           0      -1.468      -2.443           0      -2.643           0;
       1.000           0           0      -2.643           0      -1.613;
           0           0           0           0           0       1.000;
           0           0           0      -1.000           0           0;
           0       1.000       1.000           0       1.000           0];
Hst0 = [0 0 1 3; 0 1 0 1.613; -1 0 0 0; 0 0 0 1];
%
% Calculate Homogeneous transformation for the GOAL "noap"
traXYZ = u(1:3); rotXYZ = u(4:6);
noap = rotX2tform(rotXYZ(1))*rotY2tform(rotXYZ(2))*rotZ2tform(rotXYZ(3));
noap(1,4)= traXYZ(1); noap(2,4)= traXYZ(2); noap(3,4)= traXYZ(3);
%
% Calculate the IK solutions Theta using the SCREW THEORY techniques
% and basically the PADEN-KAHAN-PARDOS Canonic Subproblems.
%
% STEP1: Calculate Theta1.
% With "pf" on the axis of E4, E5, E6. We apply (noap*hs0^-1) to "pf"
% Doing so we get Theta1 applying the Canonic problem PARDOS-ONE,
% because the screws E4,E5,E6 do not affect "pf" for being on their axes
% and the E2,E3 do not change the plane where "pf" moves (perpendicular to
% the axis of those screws, and so do not affect the calculation for Theta1
% resulting the problem "exp(E1^theta1)*pf = noap*hs0^-1*pf" by PARDOS-ONE
% which has one solution for t11.
noapHst0if = noap*(Hst0\[pf; 1]); pkp = noapHst0if(1:3);
Theta(1,1) = PadenKahanPardosOne(Twist(:,1), pf, pkp);
% prepare Theta for next calculation
Theta(2,:) = Theta(1,:);
%
% STEP2: Calculate Theta2 & Theta3.
% With "pf" on the axis of E4, E5, E6 we apply (noap*hs0^-1) to "pf" and
% the POE E1..E6 also to "pf" having already known the value for Theta1
% resulting exactly a Canonic problem PARDOS-FOUR, because the screws
% E4,E5,E6 do not affect "pf" and the E1 is known,resulting the problem
% exp(E2^theta2)*exp(E3^theta3)*pf = exp(E1^Th1)^-1*noap*gs0^-1*pf = pk1p
% which by PARDOS-FOUR has none, one or two DOUBLE solutions.
% t21-t31 & t22-t32 for each value of t11
%
E1inoapHst0if = (expScrew([Twist(:,1);Theta(1,1)]))\noapHst0if;
pk1p = E1inoapHst0if(1:3);
Theta(1:2,2:3) = PardosGotorFour(Twist(:,2),Twist(:,3),pf,pk1p);
% prepare Theta for next calculation
Theta(3:4,:) = Theta(1:2,:); 
%
% STEP3: Calculate Theta4 & Theta5.
% With "pp" on the axis of E6 apply E3^-1*E2^-1*E1^-1*noap*gs0^-1 to "pp"
% and also the POE E4*E5*E6 to "pp" knowing already Theta3-Theta2-Theta1,
% resulting exactly a Canonic problem PADEN-KAHAN-TWO, because the screws
% E6 does not affect "pp" & Th3-Th2-Th1 known (four solutions), the problem
% exp(E4^theta4)*exp(E5^theta5)*pp = pk2p ; with
% pk2p = exp(E3^Th3)^-1*exp(E2^Th2)^-1*exp(E1^Th1)^-1*noap*gs0^-1*pp 
% which by PADEN-KAHAN-TWO has none, one or two DOUBLE solutions:
% t31,t21,t11 to t41-t51 & t42-t52 ; t32,t22,t11 to t43-t53 & t44-t54
%
noapHst0ip = noap*(Hst0\[pp; 1]); 
for i = 1:2
    pk2pt = (expScrew([Twist(:,1);Theta(i,1)]))\noapHst0ip;
    pk2pt = (expScrew([Twist(:,2);Theta(i,2)]))\pk2pt;
    pk2pt = (expScrew([Twist(:,3);Theta(i,3)]))\pk2pt;
    pk2p = pk2pt(1:3);
    t4t5 = PadenKahanPardosTwo(Twist(:,4),Twist(:,5),pp,pk2p);
    Theta(i,4:5) = t4t5(1,:); Theta(i+2,4:5) = t4t5(2,:);
end
%
% STEP4: Calculate Theta6.
% With "po" not in the axis of E6 apply E5^-1...*E1^-1*noap*gs0^-1 to "po"
% and applying E6 to "po" knowing already Theta5...Theta1 solutions,
% resulting exactly a Canonic problem PADEN-KAHAN-ONE, the problem:
% exp(E6^theta6)*po = pk3p ; with
% pk3p = exp(E5^Th5)^-1*...*exp(E1^Th1)^-1*noap*gs0^-1*po 
% which by PADEN-KAHAN-ONE has none or one solution. Then for all
% Th5-Th4-Th3-Th2-Th1 known (four solutions) we get t6:
noapHst0io = noap*(Hst0\[po; 1]);
for i = 1:4
    pk2pt = (expScrew([Twist(:,1);Theta(i,1)]))\noapHst0io;
    pk2pt = (expScrew([Twist(:,2);Theta(i,2)]))\pk2pt;
    pk2pt = (expScrew([Twist(:,3);Theta(i,3)]))\pk2pt;
    pk2pt = (expScrew([Twist(:,4);Theta(i,4)]))\pk2pt;
    pk2pt = (expScrew([Twist(:,5);Theta(i,5)]))\pk2pt;
    pk3p = pk2pt(1:3);
    Theta(i,6) = PadenKahanPardosOne(Twist(:,6), po, pk3p);
end
%
ThetaOut = Theta(ThetaNUM,:);
%
end
%